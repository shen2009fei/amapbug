//
//  LockedAnnotationViewController.h
//  MAMapKit
//
//  Created by shaobin on 16/9/22.
//  Copyright © 2016年 AutoNavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LockedAnnotationViewController : UIViewController

@end
