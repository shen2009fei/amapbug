//
//  MovingAnnotationViewController.h
//
//
//  Created by shaobin on 16/11/25.
//  Copyright © 2016年 autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MovingAnnotationViewController : UIViewController


@end

