//
//  MapZoomByScreenAnchor.h
//  MAMapKit_3D_Demo
//
//  Created by 翁乐 on 18/10/2016.
//  Copyright © 2016 Autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MapZoomByScreenAnchor : UIViewController

@end
