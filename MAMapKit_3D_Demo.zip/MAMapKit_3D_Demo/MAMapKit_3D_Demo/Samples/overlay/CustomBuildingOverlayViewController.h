//
//  CustomBuildingOverlayViewController.h
//  MAMapKit_3D_Demo
//
//  Created by liubo on 2018/6/5.
//  Copyright © 2018年 Autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomBuildingOverlayViewController : UIViewController

@end
