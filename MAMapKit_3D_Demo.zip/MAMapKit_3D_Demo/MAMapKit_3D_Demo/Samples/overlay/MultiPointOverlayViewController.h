//
//  MultiPointOverlayViewController.h
//  MAMapKit
//
//  Created by hanxiaoming on 2017/4/13.
//  Copyright © 2017年 Amap. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MultiPointOverlayViewController : UIViewController

@end
