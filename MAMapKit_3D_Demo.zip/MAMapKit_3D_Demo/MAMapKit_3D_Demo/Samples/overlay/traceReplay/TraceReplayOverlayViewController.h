//
//  TraceReplayOverlayViewController.h
//  MAMapKit
//
//  Created by shaobin on 2017/4/20.
//  Copyright © 2017年 Amap. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TraceReplayOverlayViewController : UIViewController

@property (nonatomic, strong) MAMapView *mapView;

@end
