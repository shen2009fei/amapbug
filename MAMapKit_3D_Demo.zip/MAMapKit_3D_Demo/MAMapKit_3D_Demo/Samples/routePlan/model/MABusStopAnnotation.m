//
//  MABusStopAnnotation.m
//  MAMapKit_3D_Demo
//
//  Created by zuola on 2019/5/7.
//  Copyright © 2019 Autonavi. All rights reserved.
//

#import "MABusStopAnnotation.h"

@implementation MABusStopAnnotation

@end
